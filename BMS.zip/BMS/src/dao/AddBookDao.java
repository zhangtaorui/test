package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import bean.addBook;
import tool.DatabaseConn;

public class AddBookDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ��ѯͼ������Ƿ��Ѿ�����Ҫ���ӵ�ͼ��
	 * @param ab
	 * @return
	 */
	public int getBookName(addBook ab){
		int i = 0;
		String sql = "SELECT name FROM books WHERE isbn = '" + ab.getIsbn() + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}
	
	/**
	 * �޸�ͼ������
	 * @param ab
	 */
	public void updateBookNumber(addBook ab){
		String sql = "UPDATE books SET number = number + " + ab.getNumber() + " WHERE isbn = '" + ab.getIsbn() + "' AND name = '" + ab.getName() + "'";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ����ͼ��
	 * @param ab
	 * @return
	 */
	public int insertBook(addBook ab){
		int i = 0;
		String sql = "INSERT INTO books(type,name,author,press,isbn,price,number,time,remark,state) VALUES('" + ab.getType() + "','" + ab.getName() + "','" + ab.getAuthor() + "','" + ab.getPress() + "','" + ab.getIsbn() + "','" + ab.getPrice() + "','" + ab.getNumber() + "','" + ab.getTime() + "','" + ab.getRemark() + "',1)";
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}	

}

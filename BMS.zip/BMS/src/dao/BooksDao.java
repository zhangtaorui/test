package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Books;

import tool.DatabaseConn;

public class BooksDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ����ͼ���б�
	 * @return
	 */
	public ArrayList<String> getBooksArrayList() {
		ArrayList<String> bl=new ArrayList<String>();
		String sql = "SELECT name FROM books";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				bl.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return bl;
	}
	
	/**
	 * ��ѯ����ͼ��
	 * @param id
	 * @return
	 */
	public Books getAllBooks(String id){
		Books books = null;
		books = new Books();
		String sql = "SELECT * FROM books WHERE id = '" + id + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if (rs != null && rs.next()) {	
				books.setId(rs.getInt(1));
				books.setType(rs.getString(2));
				books.setName(rs.getString(3));
				books.setAuthor(rs.getString(4));
				books.setPress(rs.getString(5));
				books.setIsbn(rs.getString(6));
				books.setPrice(rs.getFloat(7));
				books.setNumber(rs.getInt(8));	
				books.setTotal(rs.getFloat(7) * rs.getInt(8));
				books.setTime(rs.getString(10));
				books.setRemark(rs.getString(11));
				books.setState(rs.getInt(12));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return books;
	}
	
	/**
	 * ��ѯ����ͼ��id
	 * @return
	 */
	public ArrayList<String> getBooksId(){
		ArrayList<String> a=new ArrayList<String>();
		String sql = "SELECT id FROM books";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				a.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return a;
	}
	
	/**
	 * ɾ��ͼ��
	 * @param id
	 */
	public void deleteBook(String id){
		String sql = "DELETE FROM books WHERE id = '" + id + "'";
		conn.executeUpdate(sql);
		conn.close();
	}	
	
	/**
	 * ��ȡͼ��״̬
	 * @param id
	 * @return
	 */
	public int getBookState(String id){	
		int books = -1;		
		String sql = "SELECT state FROM books WHERE id = '" + id + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs != null && rs.next()){
				books = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return books;
	}	
	
	/**
	 * �޸�ͼ���ڹ�״̬
	 * @param id
	 * @param s
	 * @return
	 */
	public boolean updateState(int id,int state){
		String sql="UPDATE books SET state = '" + state + "' WHERE id = '" + id + "'";
		conn.executeUpdate(sql);
		conn.close();		
		return true;
	}
	
	/**
	 * �޸�ͼ����Ϣ
	 * @param b
	 */
	public int updateBook(Books b){
		int i = 0;
		String sql = "UPDATE books SET type = '" + b.getType() + "',name = '" + b.getName() + "',author = '" + b.getAuthor() + "',press = '" + b.getPress() + "',isbn = '" + b.getIsbn() + "',price = '" + b.getPrice() + "',number = '" + b.getNumber() + "',time = '" + b.getTime() + "',remark = '" + b.getRemark() + "' WHERE isbn = '" + b.getIsbn() + "'";
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}	
	
	/**
	 * ��ѯ�ڹ�ͼ��
	 * @return
	 */
	public ArrayList<String> getBooksIn(){
		ArrayList<String> B = new ArrayList<String>();
		String sql="SELECT id FROM books WHERE state = 1";
		ResultSet rs=conn.executeQuery(sql);
		try {
			while(rs.next()){
				B.add(String.valueOf(rs.getInt(1)));				
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		conn.close();
		return B;
	}
	
	/**
	 * ��ѯ�ѽ�ͼ��
	 * @return
	 */
	public ArrayList<String> getBooksOut(){
		ArrayList<String> B = new ArrayList<String>();
		String sql = "SELECT id FROM books WHERE state = 0";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while(rs.next()){
				B.add(String.valueOf(rs.getInt(1)));				
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		conn.close();
		return B;
	}
	
	/**
	 * ����ͼ����Ϣ
	 * @param id
	 * @return
	 */
	public Books getBooks(int id){
		Books books = new Books();
		String sql="SELECT * FROM books WHERE id=" + id + "";
		ResultSet rs=conn.executeQuery(sql);
		try {
			while(rs.next()){
				books.setType(rs.getString(2));
				books.setName(rs.getString(3));
				books.setAuthor(rs.getString(4));
				books.setPress(rs.getString(5));
				books.setIsbn(rs.getString(6));
				books.setPrice(rs.getFloat(7));
				books.setNumber(rs.getInt(8));	
				books.setTotal(rs.getFloat(7) * rs.getInt(8));
				books.setTime(rs.getString(10));
				books.setRemark(rs.getString(11));			
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		conn.close();
		return books;
	}
	
}

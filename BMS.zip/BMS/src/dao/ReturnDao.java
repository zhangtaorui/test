package dao;

import bean.Return;
import tool.DatabaseConn;

public class ReturnDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * �黹ͼ��
	 * @param re
	 * @return
	 */
	public int returnBook(Return re){
		int i = 0;		
		String sql = "UPDATE borrow SET borrowstate = 0";
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}	
	
	/**
	 * ����黹ʱ��
	 * @param re
	 * @return
	 */
	public int returnBookT(Return re){
		int i = 0;
		String sql = "INSERT INTO borrow(rtime) VALUES('" + re.getRtime() + "')";
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}

}

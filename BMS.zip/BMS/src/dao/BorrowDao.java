package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Borrow;

import tool.DatabaseConn;

public class BorrowDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ��ѯ�����Ƿ��Ѿ�����
	 * @param readerno
	 * @return
	 */
	public int getReaderNo(String readerno){
		int i = 0;
		String sql = "SELECT readerstate FROM readers WHERE readerno = '" + readerno + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}
	
	/**
	 * ��ѯͼ���Ƿ��Ѿ�����
	 * @param id
	 * @return
	 */
	public int getBooksId(String isbn){
		int i = 0;
		String sql = "SELECT isbn FROM books WHERE isbn = '" + isbn + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}	
	
	/**
	 * ��ȡ����״̬
	 * @param readerno
	 * @return
	 */
	public int getReaderstate(String readerno){
		int i = 0;
		String sql = "SELECT readerstate FROM readers WHERE readerno = '" + readerno + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}
	
	/**
	 * ���ͼ��
	 * @param bb
	 * @return
	 */
	public int borrowBook(Borrow bb){
		int i = 0;
		String sql = "INSERT INTO borrow(readerno,bookid,borrowstate,time) VALUES('" + bb.getReaderno() + "','" + bb.getBookid() + "',1,'" + bb.getTime() + "')";
		String sql1 = "UPDATE books SET state = 0 WHERE isbn = '" + bb.getBookid() + "'";
		conn.executeUpdate(sql1);
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}	

}

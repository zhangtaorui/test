package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.BooksInOut;

import tool.DatabaseConn;

public class BooksInOutDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ��ѯ��ʷ��¼
	 * @param name
	 * @return
	 */
	public ArrayList<String> getHistory(String name) {
		ArrayList<String> H=new ArrayList<String>();
		while(name != null){
			String sql = "SELECT id FROM books where name = '%" + name + "%'";
			ResultSet rs = conn.executeQuery(sql);
			try {
				while (rs != null && rs.next())
					H.add(rs.getString(1));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		while(name == null){
			String sql = "SELECT id FROM books";
			ResultSet rs = conn.executeQuery(sql);
			try {
				while (rs != null && rs.next())
					H.add(rs.getString(1));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		conn.close();
		return H;
	}
	
	/**
	 * ���ز�ѯ���
	 * @param id
	 * @return
	 */
	public BooksInOut getBooksHis(int id){
		BooksInOut bid = new BooksInOut();
		String sql = "SELECT * FROM books WHERE id = '" + id + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				bid.setId(rs.getInt(1));
				bid.setType(rs.getString(2));
				bid.setName(rs.getString(3));
				bid.setAuthor(rs.getString(4));
				bid.setPress(rs.getString(5));
				bid.setIsbn(rs.getString(6));				
				bid.setPrice(rs.getShort(7));
				
				bid.setBookNum(rs.getInt(8));
				bid.setInNumber(rs.getInt(9));
				//bid.setOutNumber(rs.getInt(10));
				bid.setTime(rs.getString(10));
				bid.setRemark(rs.getString(11));
				bid.setState(rs.getInt(12));			
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		conn.close();
		return bid;
	}
	
	/**
	 * ɾ����ʷ��¼
	 * @param id
	 */
	public void deleteBook(int id) {
		String sql="DELETE FROM booksOut WHERE id='" + id + "'";
		conn.executeUpdate(sql);
		conn.close();		
	}

}

package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Books;

import tool.DatabaseConn;

public class DateDao {
	private DatabaseConn conn=new DatabaseConn();
	
	/**
	 * ��ѯͼ����Ϣ
	 * @param date1
	 * @param date2
	 * @return
	 */
	public ArrayList<String> getTimeArrayList(String date1,String date2) {
		ArrayList<String> D = new ArrayList<String>();
		while(date1!=null&&date2!=null){
			String sql = "SELECT * FROM books WHERE time >= '" + date1 + "' AND time <= '" + date2 + "'";
			ResultSet rs = conn.executeQuery(sql);
			try {
				while (rs != null && rs.next())
					D.add(rs.getString(10));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		while(date1 == null && date2 == null){
			String sql = "SELECT * FROM books";
			ResultSet rs = conn.executeQuery(sql);
			try {
				while (rs != null && rs.next())
					D.add(rs.getString(10));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		conn.close();
		return D;
	}
	
	/**
	 * ��ʱ��˳�����ͼ����Ϣ
	 * @param date
	 * @param date1
	 * @param date2
	 * @return
	 */
	public Books getAllBooks(String date,String date1,String date2){
		Books books = new Books();
		while(date1 != null && date2 != null){
			String sql = "SELECT * FROM books WHERE time = '" + date + "' AND time >= '" + date1 + "'AND time <= '" + date2 + "'";
			ResultSet rs = conn.executeQuery(sql);	
			try {
				if(rs.next()){
					books.setId(rs.getInt(1));
					books.setType(rs.getString(2));
					books.setName(rs.getString(3));
					books.setAuthor(rs.getString(4));
					books.setPress(rs.getString(5));
					books.setIsbn(rs.getString(6));
					books.setPrice(rs.getFloat(7));
					books.setNumber(rs.getInt(8));	
					books.setTotal(rs.getFloat(7) * rs.getInt(8));
					books.setTime(rs.getString(10));
					books.setRemark(rs.getString(11));
					books.setState(rs.getInt(12));
				}
			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			break;
		}
		while(date1 == null && date2 == null){
			String sql = "SELECT * FROM books WHERE time = '" + date + "'";
			ResultSet rs = conn.executeQuery(sql);	
				try {
					if(rs.next()){
						books.setId(rs.getInt(1));
						books.setType(rs.getString(2));
						books.setName(rs.getString(3));
						books.setAuthor(rs.getString(4));
						books.setPress(rs.getString(5));
						books.setIsbn(rs.getString(6));
						books.setPrice(rs.getFloat(7));
						books.setNumber(rs.getInt(8));	
						books.setTotal(rs.getFloat(7) * rs.getInt(8));
						books.setTime(rs.getString(10));
						books.setRemark(rs.getString(11));
						books.setState(rs.getInt(12));
					}
				} catch (SQLException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			}
		conn.close();
		return books;	
		
	}
	
	/**
	 * ɾ����¼
	 * @param time
	 */
	public void deleteBook(String time) {
		String sql = "DELETE FROM books WHERE time = '" + time + "'";
		conn.executeUpdate(sql);
		conn.close();		
	}
	
	/**
	 * ��ѯ����ͼ��id
	 * @return
	 */
	public ArrayList<String> getBooksId(){
		ArrayList<String> a=new ArrayList<String>();
		String sql = "SELECT id FROM books";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				a.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return a;
	}		
	
	/**
	 * ��ʱ���ѯ��Ϣ
	 * @param date1
	 * @param date2
	 * @return
	 */
	public ArrayList<String> getBooksIdDate(String date1,String date2){
		ArrayList<String> bid = new ArrayList<String>();
		String sql = "SELECT id FROM books WHERE time >= '" + date1 + "' AND time <= '" + date2 + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				bid.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return bid;
	}
	
	/**
	 * ��ѯ����ͼ��
	 * @param id
	 * @return
	 */
	public Books getAllBooks(String id){
		Books books = null;
		books = new Books();
		String sql = "SELECT * FROM books WHERE id = '" + id + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if (rs != null && rs.next()) {	
				books.setId(rs.getInt(1));
				books.setType(rs.getString(2));
				books.setName(rs.getString(3));
				books.setAuthor(rs.getString(4));
				books.setPress(rs.getString(5));
				books.setIsbn(rs.getString(6));
				books.setPrice(rs.getFloat(7));
				books.setNumber(rs.getInt(8));	
				books.setTotal(rs.getFloat(7) * rs.getInt(8));
				books.setTime(rs.getString(10));
				books.setRemark(rs.getString(11));
				books.setState(rs.getInt(12));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return books;
	}

}

package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Users;

import tool.DatabaseConn;

public class UsersDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ��ѯ��¼�û�
	 * @param username
	 * @return
	 */
	public String getLoginUser(String username){
		String pd = null;
		String sql = "SELECT password FROM users WHERE username = '" + username + "'";
		ResultSet rs = conn.executeQuery(sql);		
		try {
			if(rs != null && rs.next()){
				pd = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();			
		}
		conn.close();
		return pd;
	}
	
	/**
	 * �û����Ƿ��Ѿ�����
	 * @param username
	 * @return
	 */
	public int getUserName(String username){
		int i = 0;
		String sql = "SELECT level FROM users WHERE username = '" + username + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}
	
	/**
	 * ע���û�
	 * @param u
	 */
	public void insertUser(Users u){
		String sql = "INSERT INTO users VALUES('" + u.getUsername() + "','" + u.getPassword() + "','" + u.getRealname() + "','" + u.getTel() + "',0)";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ����Ա�����û�
	 * @param u
	 */
	public void addUser(Users u){
		String sql = "INSERT INTO users VALUES('" + u.getUsername() + "','" + u.getPassword() + "','" + u.getRealname() + "','" + u.getTel() + "','" + u.getLevel() + "')";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ɾ���û�
	 * @param username
	 */
	public void deleteUser(String username){
		String sql = "DELETE FROM users WHERE username = '" + username + "'";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ��ѯ�����û�
	 * @param username
	 * @return
	 */
	public Users getAllUsers(String username){
		Users users = null;
		users= new Users();
		String sql = "SELECT * FROM users WHERE username = '" + username + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if (rs != null && rs.next()) {				
				users.setUsername(rs.getString(1));
				users.setPassword(rs.getString(2));
				users.setRealname(rs.getString(3));
				users.setTel(rs.getString(4));
				users.setLevel(rs.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return users;
	}
	
	/**
	 * �޸��û�Ȩ��
	 * @param u
	 * @param l
	 * @return
	 */
	public boolean updateLevel(String u,int l){
		String sql="UPDATE users SET level = " + l + " WHERE username = '" + u + "'";
		conn.executeUpdate(sql);
		conn.close();
		return true;
	}
	
	/**
	 * �����û��б�
	 * @return
	 */
	public ArrayList<String> getUsersArrayList() {
		ArrayList<String> ul = new ArrayList<String>();
		String sql = "SELECT username FROM users";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				ul.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return ul;
	}
	
	/**
	 * �޸��û���Ϣ
	 * @param u
	 * @return
	 */
	public int updateUser(Users u){
		int i = 0;
		String sql = "UPDATE users SET password = '" + u.getPassword() + "',realname = '" + u.getRealname() + "',tel = '" + u.getTel() + "',level = '" + u.getLevel() + "' WHERE username = '" + u.getUsername() + "'";
		i = conn.executeUpdate(sql);
		conn.close();
		return i;
	}		
	
	/**
	 * ��ȡ�û�Ȩ��
	 * @param username
	 * @return
	 */
	public int getUserLevel(String username){
		int pwd = -1;
		String sql = "SELECT level FROM users WHERE username = '" + username + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs != null && rs.next()){
				pwd = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return pwd;
	}

}

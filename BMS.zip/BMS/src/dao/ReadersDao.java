package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Readers;

import tool.DatabaseConn;

public class ReadersDao {
	private DatabaseConn conn = new DatabaseConn();
	
	/**
	 * ��ѯ�����Ƿ��Ѿ�����
	 * @param readerno
	 * @return
	 */
	public int getReaderNo(String readerno){
		int i = 0;
		String sql = "SELECT readerstate FROM readers WHERE readerno = '" + readerno + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if(rs.next()){
				i = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return i;
	}
	
	/**
	 * ���Ӷ���
	 * @param r
	 */
	public void addReader(Readers r){
		String sql = "INSERT INTO readers(readerno,readername,sex,tel,department,readerstate) VALUES('" + r.getReaderno() + "','" + r.getReadername() + "','" + r.getSex() + "','" + r.getTel() + "','" + r.getDepartment() + "',1)";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ɾ������
	 * @param readerno
	 */
	public void deleteReader(String readerno){
		String sql = "DELETE FROM readers WHERE readerno = '" + readerno + "'";
		conn.executeUpdate(sql);
		conn.close();
	}
	
	/**
	 * ��ȡ������Ϣ
	 * @param readerno
	 * @return
	 */
	public Readers getAllReaders(String readerno){
		Readers readers = null;
		readers= new Readers();
		String sql = "SELECT * FROM readers WHERE readerno = '" + readerno + "'";
		ResultSet rs = conn.executeQuery(sql);
		try {
			if (rs != null && rs.next()) {
				readers.setReaderno(rs.getString(1));
				readers.setReadername(rs.getString(2));	
				readers.setSex(rs.getString(3));
				readers.setAge(rs.getString(4));
				readers.setBooknumber(rs.getString(5));
				readers.setTel(rs.getString(6));		
				readers.setDepartment(rs.getString(7));
				readers.setReaderstate(rs.getInt(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return readers;
	}
	
	/**
	 * �޸Ķ���״̬
	 * @param r
	 * @param s
	 * @return
	 */
	public boolean updateState(String r,int s){
		String sql="UPDATE readers SET readerstate = " + s + " WHERE readerno = '" + r + "'";
		conn.executeUpdate(sql);
		conn.close();
		return true;
	}
	
	/**
	 * ��ȡ�����б�
	 * @return
	 */
	public ArrayList<String> getReadersArrayList() {
		ArrayList<String> rl = new ArrayList<String>();
		String sql = "SELECT readerno FROM readers";
		ResultSet rs = conn.executeQuery(sql);
		try {
			while (rs != null && rs.next())
				rl.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		return rl;
	}

}

package tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConn {
	public static String DBDRIVER = "com.mysql.jdbc.Driver";
	public static String DBURL = "jdbc:mysql://127.0.0.1:3306/test?useUnicode=true&characterEncoding=utf-8";
	public static String DBUSER = "root";
	public static String DBPASS = "admin";
	
	private static Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	
	/**
	 * ��������
	 */
	public DatabaseConn(){
		try {
			Class.forName(DBDRIVER);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("��������ʧ��!");
		}
	}
	
	/**
	 * �������ݿ�
	 * @return
	 */
	public static Connection getConnection(){
		try {
			conn = DriverManager.getConnection(DBURL, DBUSER, DBPASS);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("���ݿ�����ʧ��!");
		}
		return conn;
	}
	
	/**
	 * ��ѯ��¼����
	 * @param sql
	 * @return
	 */
	public ResultSet executeQuery(String sql){
		conn = getConnection();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs == null){
			System.out.println("ִ�в�ѯ����ʧ�ܣ�");
		}
		return rs;		
	}
	
	/**
	 * �޸ģ�ɾ�������¼�¼����
	 * @param sql
	 * @return
	 */
	public int executeUpdate(String sql){
		int result = 0;
		conn = getConnection();
		try {
			stmt = conn.createStatement();
			result = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("ִ��ʧ�ܣ�");
			result = 0;
		}
		return result;//ִ��Ӱ�������
	}
	
	/**
	 * �ر����ݿ�
	 */
	public void close(){
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(stmt != null){
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
//	public static void main(String[] args) {
//		DatabaseConn base=new DatabaseConn();
//		Connection connection=base.getConnection();
//		String insertSQL="insert into tb_user(username,password) values('12','5')";
//		String deleteSQL="delete from tb_user where username='12'";
//		base.executeUpdate(insertSQL);
//		
//	}

}

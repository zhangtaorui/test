package bean;

public class BooksInOut {
	private int id;			//���
	private String type;	//����
	private String name;	//ͼ������
	private String author;	//����
	private String press;	//������
	private String isbn;	//isbn���
	private float price;	//����	
	private float total;	//�ܼ�ֵ
	private String time;	//����ʱ��
	private String remark;	//��ע
	private int state;		//״̬
	private int bookNum=0;	//�ڹ�����
	private int inNumber=0; //�������
	private int outNumber=0;//��������
	
	public BooksInOut(){}
	public BooksInOut(int id,String type,String name,String author,String press,String isbn,float price,
			float total,String time,String remark,int state,int inNumber,int bookNum,int outNumber){		
		this.name=name;
		this.author=author;		
		this.isbn=isbn;
		this.price=price;		
		this.inNumber=inNumber;
		this.outNumber=outNumber;
		this.bookNum=bookNum;
		this.time=time;	
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getBookNum() {
		return bookNum;
	}
	public void setBookNum(int bookNum) {
		this.bookNum = bookNum;
	}
	public int getInNumber() {
		return inNumber;
	}
	public void setInNumber(int inNumber) {
		this.inNumber = inNumber;
	}
	public int getOutNumber() {
		return outNumber;
	}
	public void setOutNumber(int outNumber) {
		this.outNumber = outNumber;
	}
	
}

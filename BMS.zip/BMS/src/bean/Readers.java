package bean;

public class Readers {
	private String readerno;
	private String readername;
	private String sex;
	private String age;
	private String booknumber;
	private String tel;
	private String department;
	private int readerstate;
	
	public int getReaderstate() {
		return readerstate;
	}
	public void setReaderstate(int readerstate) {
		this.readerstate = readerstate;
	}
	public String getReaderno() {
		return readerno;
	}
	public void setReaderno(String readerno) {
		this.readerno = readerno;
	}
	public String getReadername() {
		return readername;
	}
	public void setReadername(String readername) {
		this.readername = readername;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getBooknumber() {
		return booknumber;
	}
	public void setBooknumber(String booknumber) {
		this.booknumber = booknumber;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}	
}

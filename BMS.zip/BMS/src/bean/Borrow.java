package bean;

public class Borrow {
	private int id;
	private String readerno;	
	private int bookid;
	private int borrowstate;
	private String time;	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReaderno() {
		return readerno;
	}
	public void setReaderno(String readerno) {
		this.readerno = readerno;
	}	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public int getBorrowstate() {
		return borrowstate;
	}
	public void setBorrowstate(int borrowstate) {
		this.borrowstate = borrowstate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}

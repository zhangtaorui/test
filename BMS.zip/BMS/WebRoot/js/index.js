//ȫѡ
function selectAll() {
	var obj=document.all.checkbox;
	var j=0;
	for(var i=0;i<obj.length;i++){
 		if(obj[i].checked==false){
 			j++;
 		}  			
	}
	if(j==0){
 		for(var i=0;i<obj.length;i++){
 			obj[i].checked=false;
 		}		
	}else{
 		for(var i=0;i<obj.length;i++){
 			obj[i].checked=true;
 		}
	}
}

//*ָ��ҳ���������ݵ���Excel
function AllAreaExcel(){
	var oXL = new ActiveXObject("Excel.Application");
	var oWB = oXL.Workbooks.Add();
	var oSheet = oWB.ActiveSheet;
	var sel=document.body.createTextRange();
	sel.moveToElementText(list);
	sel.select();
	sel.execCommand("Copy");
	oSheet.Paste();
	oXL.Visible = true;
}

//ָ��ҳ�����򡰵�Ԫ�����ݵ���Excel
function CellAreaExcel(){
	var oXL = new ActiveXObject("Excel.Application");
	var oWB = oXL.Workbooks.Add();
	var oSheet = oWB.ActiveSheet;
	var Lenr = list.rows.length;
	for (i=0;i<Lenr;i++){
		var Lenc = list.rows(i).cells.length;
		for (j=0;j<Lenc;j++){
			oSheet.Cells(i+1,j+1).value = list.rows(i).cells(j).innerText;
		}
	}
	oXL.Visible = true;
}

//*ָ��ҳ���������ݵ���Word
function AllAreaWord(){
	var oWD = new ActiveXObject("Word.Application");
	var oDC = oWD.Documents.Add("",0,1);
	var oRange =oDC.Range(0,1);
	var sel = document.body.createTextRange();
	sel.moveToElementText(list);
	sel.select();
	sel.execCommand("Copy");
	oRange.Paste();
	oWD.Application.Visible = true;
}
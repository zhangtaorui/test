/*
SQLyog Enterprise - MySQL GUI v6.14
MySQL - 5.1.49-community : Database - bms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `bms`;

USE `bms`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `books` */

DROP TABLE IF EXISTS `books`;

CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `author` varchar(10) DEFAULT NULL,
  `press` varchar(25) DEFAULT NULL,
  `isbn` varchar(15) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `total` float DEFAULT NULL,
  `time` varchar(15) DEFAULT NULL,
  `remark` mediumtext,
  `state` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=gbk;

/*Data for the table `books` */

insert  into `books`(`id`,`type`,`name`,`author`,`press`,`isbn`,`price`,`number`,`total`,`time`,`remark`,`state`) values (3,'外语','英语','都是','盛大撒萨','4545454',23,3232,NULL,'2011-06-14','上的发生大幅',1),(4,'艺术','的说法','飞','实得分','3434343',23,4,0,'2011-06-14','对方身份',1),(5,'医药学','医学1','医学2','医学3','123456',123,2,NULL,'2011-02-03','医学数据',1),(6,'医药学','医学1','医学2','医学3','123456',123,2,NULL,'2011-02-03','医学数据',0),(9,'军事','军事','军事','军事','333',333,333,NULL,'2011-06-21','军事',1);

/*Table structure for table `borrow` */

DROP TABLE IF EXISTS `borrow`;

CREATE TABLE `borrow` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `readerno` varchar(15) DEFAULT NULL,
  `bookid` int(4) DEFAULT NULL,
  `borrowstate` int(1) DEFAULT NULL,
  `time` varchar(15) DEFAULT NULL,
  `rtime` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=gbk;

/*Data for the table `borrow` */

insert  into `borrow`(`id`,`readerno`,`bookid`,`borrowstate`,`time`,`rtime`) values (1,'33232',0,0,NULL,NULL),(2,'4343343',0,0,'2011-06-21',NULL),(3,'4343343',0,0,'2011-06-21',NULL),(4,'4343343',0,0,'2011-06-21',NULL),(5,'4343343',0,0,'2011-06-21',NULL),(6,'333',0,0,'2011-06-21',NULL),(7,'333',0,0,'2011-06-21',NULL),(11,NULL,NULL,0,NULL,'null'),(12,'111',0,0,'2011-06-21',NULL),(13,'111',0,0,'2011-06-21',NULL),(14,'3333',0,0,'2011-06-22',NULL),(15,'3333',0,0,'2011-06-22',NULL),(16,NULL,NULL,0,NULL,'null');

/*Table structure for table `readers` */

DROP TABLE IF EXISTS `readers`;

CREATE TABLE `readers` (
  `readerno` varchar(15) NOT NULL,
  `readername` varchar(10) DEFAULT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `age` varchar(8) DEFAULT NULL,
  `booknumber` int(2) DEFAULT '0',
  `tel` varchar(15) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `readerstate` tinyint(1) DEFAULT '1',
  `remark` mediumtext,
  PRIMARY KEY (`readerno`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*Data for the table `readers` */

insert  into `readers`(`readerno`,`readername`,`sex`,`age`,`booknumber`,`tel`,`department`,`readerstate`,`remark`) values ('111111','呵呵','null',NULL,0,'12212121','23232',1,NULL),('222222','22222','null',NULL,0,'2222222','222',0,NULL),('2222222','aaa','null',NULL,NULL,'223223','dsasafsda',0,NULL),('4343343','fdsfdssdf',NULL,NULL,NULL,'3434343','的发生过分的是',0,NULL),('null','null','null',NULL,0,'null','null',1,NULL);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `username` varchar(10) NOT NULL,
  `password` varchar(15) DEFAULT NULL,
  `realname` varchar(10) DEFAULT NULL,
  `tel` varchar(12) DEFAULT NULL,
  `level` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*Data for the table `users` */

insert  into `users`(`username`,`password`,`realname`,`tel`,`level`) values ('aaa','123456','毛军伟','123456789',1),('admin','123456','毛军伟','1234567',1),('bbb','123456','方法','43434343',0),('cccccc','cccccc','呵呵','123456',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
